# 数据接口契约（前台交付视角）

> 仓库内对应文档：`docs/FRONTEND-GUIDE.md`。改契约时文档 + Functions + worker + 后台四处同步。

## 通用规则

- 数据全部是「挂全局变量的 JS 文件」，**不是 JSON**：`<script>` 引入或 `injectScript`
  之后直接读全局变量；
- 唯一写入通道：微信 bot / 在线后台 → D1（Tier2）或直接提交仓库（Tier0/1）；
- 响应头 `X-Data-Source`：`d1-authoritative`（D1 权威）/ `static`（静态回退）/
  `static-d1-error`（D1 异常降级）；均带 `ETag`，`If-None-Match` 命中回 304；
- 仓库里的数据目录是历史快照（降级副本），会变旧，**不要引用它做业务判断**；
- 前台渲染必须容错：降级态可能返回旧数据，内容也可能已被删除。

## 数据路径与全局变量

`index.html` 静态引入：

| URL | 全局变量 | 内容 |
|---|---|---|
| `data/meta.js` | `SITE_META` | 站名、副标题、起始年份、头像 |
| `data/watch-meta.js` | `WATCH_META` | 观影/读书统计 |
| `data/posts.js` | `POSTS` | 文章列表（无正文） |
| `data/links.js` | `FRIEND_LINKS` | 友链 |
| `data/photos.js` | `PHOTO_WALL` | 图片墙 |

`app.js` 动态 `injectScript`：

| URL | 全局变量 | 备注 |
|---|---|---|
| `data/catalog.js` | `MOMENT_CATALOG` | 瞬间名录，查重/搜索用 |
| `data/todos.js` | `TODOS` | 待办 |
| `data/moments.js` | `MOMENTS_YEARS` | 年份清单（几百字节） |
| `data/moments-<YYYY>.js` | `MOMENTS_PARTS["YYYY"]` | 年卷，用到哪年拉哪年 |
| `data/days-<YYYY>.js` | 合并进 `WATCH_DAYS` | 观影天索引，按年拆 |
| `data/content/<slug>.js` | `POST_CONTENT[slug]` | 正文，一篇一文件 |

## 编码规则（踩过坑）

- `data/content/` 的 slug 必须 `encodeURIComponent`，**只编码 slug 本身**：
  正确 `data/content/${encodeURIComponent(slug)}.js`；
  错误 `encodeURIComponent('data/content/' + slug + '.js')`——全路径编码会落到静态回退、拿旧数据。
- 仓库里的文件名用**原始 slug**（中文算 Letter，文件名安全）。编码只发生在浏览器请求 URL，
  不发生在 GitHub 路径。写进仓库 path 时编码 = 生成 `%XX` 字面量文件名 → 前台 404。

## 接管范围

- `functions/data/[[path]].js` 只接管 `/data/*`，`_routes.json` 的 `include` 必须与之对应；
- 其余路径保持**纯静态**（不进 Functions），免费额度与延迟都不受影响；
- 新增数据目录 = 改 `SITE_SPEC`（`dataDelRe` 决定备份删除同步的范围，给宽了会删代码）。

## 改契约的纪律

URL 路径、文件名、全局变量名属于**四处镜像契约**：
Functions 文件 / worker（`SITE_SPEC` 与暂存处理）/ 在线后台 / 前台代码。
改前读 `docs/SITE-STANDARD.md`，改完跑 `node test.mjs` + 线上验证 `X-Data-Source`。
