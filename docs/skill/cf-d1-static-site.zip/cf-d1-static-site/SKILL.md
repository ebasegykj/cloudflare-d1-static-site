---
name: cf-d1-static-site
description: |-
  接手或运维「静态站 + Cloudflare D1 数据层」这类项目时使用。涵盖：D1 files 表数据架构、Pages Functions 数据接管契约（X-Data-Source 头）、SITE_SPEC 站点差异注册表、微信 bot / 在线后台两条写入通道、data-backup 分支灾备（备份/恢复/核对）、部署验证（push 不等于上线）、以及踩坑速查。触发词：D1、数据迁移、备份D1、恢复D1、核对D1、导入D1、数据源切换、Pages Functions、data-backup、静态站数据层、退出降级。
agent_created: true
---

# 静态站 + D1 数据层：架构与运维

> 适用前提：站点是**纯静态**的（Cloudflare Pages），代码在 GitHub，数据原本是仓库里的一堆
> `.js` 文件，现在要把数据搬进 Cloudflare D1，同时**不改变前台的 URL 契约**。
> 这套方法在一个跑了数年的个人站上验证过：文字数据进 D1，图片外置，代码留 GitHub。

## 核心架构（10 秒版）

```
微信 bot ──┐
           ├→ Worker ──→ D1（files 表: path / body / updated_at）
在线后台 ──┘      │
                  └──→ data-backup 分支（每日 cron + 手动命令，差量 blob 提交）

浏览器 ──→ Pages Functions（接管 /data/*）──→ D1 命中直接输出
                └─ D1 未导入 / 异常 → 自动回退仓库静态副本（恢复后自动切回）
```

三个设计决定，别轻易推翻：

1. **D1 当"文件系统"用**：`files(path TEXT PRIMARY KEY, body TEXT, updated_at INTEGER)`，
   一行 = 一个旧数据文件，`body` 是文件全文、**与旧静态文件逐字节一致**。
   不做关系表——收益为零、迁移风险放大，将来真有查询需求再议。
2. **`__meta/imported` 标记行 = 切换开关**：没有它，Functions 查不到就回退静态（双轨期）；
   有它，D1 是唯一真相，查不到就 404（否则删掉的文章会从静态副本里"诈尸"）。
3. **前台契约零变化**：URL、文件名、全局变量名都不变，响应头用
   `X-Data-Source: d1-authoritative | static | static-d1-error` 标注数据源。

## 接手前必读（按序）

1. 仓库纪律与硬规则：`AGENTS.md`；
2. **踩坑实录**：`docs/PITFALLS.md`（现象/根因/规则/验证四段式）——改完 bug 必须补录；
3. 数据语义差异唯一注册表：`wecom-worker/worker.js` 顶部 `SITE_SPEC`
   （`dbVar` / `manifest` / `dataDelRe`），改路径只动这一处；
4. 前台数据接口契约：`docs/FRONTEND-GUIDE.md`；
5. 接入手册：`docs/SETUP.md`（Tier0/1/2）。

## 铁律（违反即事故）

1. **只改代码，不碰数据**；动手前 `git pull --rebase`，禁 merge、禁 force push；
2. 数据文件禁止本地编辑提交（pre-commit / pre-push 会拦；紧急放行
   `ALLOW_DATA_COMMIT=1`，仅用于初始化导入这类纯数据提交，且单独一趟 push）；
3. worker 改动必 bump `BUILD`，部署后访问 `/version` 核对；
4. 改 worker 必跑测试：`cd wecom-worker && node test.mjs`（**必须在该目录下跑**）；
5. D1 API：`prepare().bind()` 返回不可 await 的语句，**必须接 `.run()` / `.all()` /
   `.first()` 或进 `batch()`**，漏 `.run()` 静默不执行；
6. 新增暂存标记必须同步登记 flush 的跳过清单，删类操作必须有端到端用例；
7. 循环发 fetch 的批处理必须限批（免费版单次调用 50 子请求）+ KV 游标续传；
8. `waitUntil` 后台任务结果必须落 KV（推送可能被企业微信 IP 白名单静默拦截）；
9. 读文件生成快照/备份时统一 CRLF→LF（仓库存 LF，不归一会导致差量全量命中）；
10. push 后必须验证线上真的部署了（Pages 偶发漏自动部署，「重试部署」只重跑旧提交）：
    空提交触发重建，或用比对线上 sha256 的部署脚本。

## 运维命令（微信端）

| 命令 | 作用 |
|---|---|
| `数据源` | 当前源（D1 / GitHub）+ 备份状态 + 切换方法 |
| `数据源D1` / `数据源GitHub` | 互斥切换（写/删 `__meta/imported`） |
| `备份D1` | 手动备份到 `data-backup` 分支（另有每日 cron；量大自动分批，按提示续发） |
| `恢复D1` | D1 数据丢失时从备份分支灌回（分批续传） |
| `备份结果` | 上次备份/恢复结果（推送被拦时的兜底查询） |
| `导入D1` / `核对D1` | 仓库快照灌入 D1 / D1 与快照全表逐行比对（仅迁移期用） |

后台网页端：设置页有数据源徽章 + 互斥切换按钮（走 worker `/api/admin/source`）。

## 迁移顺序（照做，别跳）

```
建 D1 + 绑 DB →  gen-import 生成快照 → 提交快照 → 导入D1 → 核对D1
   → 验证 X-Data-Source: d1-authoritative → 首次备份D1 → 决定仓库 data/ 去留
```

两个常见翻车点：

- **快照过期**：`node tools/gen-import.mjs` 生成之后又发过内容 → 必须重新生成再导入；
- **没核对就删 `data/`**：`核对D1` 是唯一的一致性证据，删数据目录前必须全绿。

## 详细资料（按需加载）

- [references/data-contract.md](references/data-contract.md) —— 数据接口契约全景
  （URL、全局变量、编码规则、缓存与响应头）；
- [references/ops-playbook.md](references/ops-playbook.md) —— 运维手册：灾备双选一、
  恢复演练、限额表、排障顺序、踩坑速查索引。
